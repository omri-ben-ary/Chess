#ifndef EX1Q3_PAIR_H
#define EX1Q3_PAIR_H

typedef void* Key;
typedef void* Value;

typedef struct {
    Key key;
    Value value;
}Pair;

#endif //EX1Q3_PAIR_H
